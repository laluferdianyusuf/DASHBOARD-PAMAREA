---
name: PAMAREA Enterprise Security Core
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434655'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#535e7b'
  on-secondary: '#ffffff'
  secondary-container: '#d2dcff'
  on-secondary-container: '#56607e'
  tertiary: '#006243'
  on-tertiary: '#ffffff'
  tertiary-container: '#007d57'
  on-tertiary-container: '#bdffdc'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dae2ff'
  secondary-fixed-dim: '#bbc6e8'
  on-secondary-fixed: '#101b35'
  on-secondary-fixed-variant: '#3c4662'
  tertiary-fixed: '#85f8c4'
  tertiary-fixed-dim: '#68dba9'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  code-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0em
  table-header:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  badge-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system targets privileged access management, compliance monitoring, and incident oversight for mission-critical enterprise environments. The aesthetic embodies high-density structural minimalism: utilitarian, razor-sharp, strictly unembellished, and architected for rapid scanning across hundreds of audit trails and permission trees.

### Guiding Principles
- **Density Over Decoration:** No drop shadows, floating nested cards, or ornamental gradients. Boundaries and hierarchy are articulated purely through hairline borders (`#E2E8F0`), intentional whitespace, and tonal contrast.
- **Uncompromised Operational Clarity:** Critical audit indicators, IP addresses, session states, and timestamps remain immediately legible with strict alignment and tabular spacing.
- **Authoritative Indonesian Security Tone:** Terminology and system interactions employ institutional, standard Indonesian governance nomenclature (*Hak Akses, Otentikasi, Jejak Audit, Temuan Kepatuhan, Tanggap Insiden*), reinforcing absolute operational rigor.

## Colors

The system uses a tri-tier canvas architecture: an authoritative dark navy structural navigation frame, a quiet cool-gray utility backing, and pure white operative planes.

### Palette Architecture
- **Navigation & Structural Anchor:**
  - Sidebar Primary: `#101B35`
  - Sidebar Dark Active / Inset: `#0B132B`
  - Sidebar Border: `#1E293B`
  - Sidebar Text Active: `#FFFFFF`
  - Sidebar Text Inactive: `#94A3B8`
- **Application Canvases:**
  - Workspace Base: `#F7F8FA`
  - Operative Data Canvas / Tables: `#FFFFFF`
- **Interactive Action Colors:**
  - Primary Action Default: `#2563EB`
  - Primary Action Hover / Active: `#1D4ED8`
  - Focus Ring Indicator: `rgba(37, 99, 235, 0.25)`
- **Structural Outlines:**
  - Border Primary: `#E2E8F0`
  - Border Light (Row dividers): `#EAECF0`
- **Text & Foreground:**
  - Primary Ink (Headings, key identifiers): `#0F172A`
  - Secondary Ink (Labels, metadata): `#334155`
  - Muted Ink (Helper text, inactive icons): `#64748B`
  - Disabled Ink: `#94A3B8`

### Security Status & Semantic Badges
Status indicators pair high-contrast text against 50-tint background fills with matched 200-level subtle borders:
- **Aktif / Aman (Success):** Text `#059669`, Background `#ECFDF5`, Border `#A7F3D0`
- **Temuan / Pengawasan (Warning):** Text `#D97706`, Background `#FFFBEB`, Border `#FDE68A`
- **Insiden / Kritis (Danger):** Text `#DC2626`, Background `#FEF2F2`, Border `#FECACA`
- **Informasi / Sesi Berjalan (Info):** Text `#2563EB`, Background `#EFF6FF`, Border `#BFDBFE`
- **Nonaktif / Dicabut (Inactive):** Text `#64748B`, Background `#F1F5F9`, Border `#E2E8F0`

## Typography

Typography relies uniformly on **Inter** to ensure maximum legibility across complex operational tables, IP hashes, and session timers.

### Numerical Data & Tabular Alignment
- All tables, session durations, timestamps, and network addresses must activate tabular lining figures using OpenType settings (`font-feature-settings: "tnum" 1, "cv05" 1`).
- Hashes, API keys, and machine tokens render in `code-md` using a muted gray tone (`#334155`).

### Hierarchy & Table Headers
- Primary administrative page titles maintain a restrained ceiling of 24px (`headline-lg`) to preserve above-the-fold table surface.
- Table headers enforce uppercase treatment via CSS (`text-transform: uppercase`) paired with `table-header` (11px, weight 600, letter-spacing +0.06em) in `#64748B`.

## Layout & Spacing

The application implements a strict two-column administrative master layout: a fixed-width dark navy navigational sidebar (240px desktop, collapsible to 64px icon-rail) and an elastic, full-bleed operative workbench.

### Spatial Model
- **Work Area:** Background `#F7F8FA` with inner horizontal margins of `2rem` (32px) and top/bottom padding of `1.5rem` (24px).
- **Zero-Margin Data Tables:** Data grids sit directly within clean border-framed containers spanning 100% of their content column width.
- **Component Tightness:** Spacing within input fields, segmented buttons, and table rows adheres strictly to multiples of 4px, prioritizing compact usability over spacious breathing room.

## Elevation & Depth

This system operates entirely on **Low-Contrast Outlines and Hairline Tonal Borders**. Elevation through box-shadows is prohibited across operational surfaces.

### Depth Hierarchy
1. **Level 0 (App Canvas Base):** `#F7F8FA` provides neutral background separation for workspace pages.
2. **Level 1 (Data Surfaces & Tables):** `#FFFFFF` bordered with 1px solid `#E2E8F0`. No drop shadow.
3. **Level 2 (Dropdowns, Popovers, & Context Menus):** `#FFFFFF` with 1px solid `#CBD5E1` and a hyper-subtle focus boundary (`0 4px 6px -1px rgba(15, 23, 42, 0.06)`).
4. **Level 3 (Modal Overlays / Konfirmasi Hak Akses):** `#FFFFFF` with 1px solid `#94A3B8`, elevated above a backdrop scrim of `#0F172A` at 40% opacity.

## Shapes

The design uses tight, disciplined geometry:
- **Base Radii (Level 1 - Soft / 4px):** Form fields, action buttons, table containment corners, and search bars use a crisp 4px corner radius.
- **Pill Badges:** Status pills (`badge-sm`) leverage a full pill radius (`9999px`) to create an immediate shape distinction between interactive buttons and static audit indicators.
- **Dividers & Borders:** Form and table borders maintain an exact 1px width. Never exceed 1px.

## Components

### 1. Data Tables
- **Container:** Wrapped in a single 1px solid `#E2E8F0` container with top and bottom borders cleanly bounding the dataset. No card-wrapping or shadow frames.
- **Header:** Height 36px, background `#F8FAFC`, bottom border 1px solid `#E2E8F0`. Text formatted with `table-header` in `#64748B`.
- **Rows:** Strict 48px row height (`min-height: 48px`). Alternating striping is prohibited; subtle hover state on row is `#F8FAFC`. Divider is 1px solid `#EAECF0`.
- **Text Alignment:** Left-aligned for text and entity identifiers; right-aligned for numeric metrics, counts, and action buttons; center-aligned for standalone status badges.

### 2. Flat Inline Filters
- Positioned directly above the data grid with zero nested card borders.
- Search input, role dropdown filter (*Peran Akses*), status toggle (*Status Sesi*), and export triggers sit flush in a horizontal flex layout with 8px (`space-sm`) gaps.

### 3. Buttons & Action Triggers
- **Primary:** Background `#2563EB`, text `#FFFFFF`, height 36px, padding 0 14px, weight 500. Hover `#1D4ED8`. Active `#1E40AF`.
- **Secondary / Outline:** Background `#FFFFFF`, border 1px solid `#E2E8F0`, text `#334155`. Hover background `#F8FAFC`, border `#CBD5E1`.
- **Destructive (*Cabut Hak Akses / Blokir*):** Background `#DC2626`, text `#FFFFFF`. Hover `#B91C1C`.
- **Subtle Row Actions:** Height 28px, width 28px icon button, background transparent, border none, icon color `#64748B`. Hover `#F1F5F9` with icon `#0F172A`.

### 4. Status Badges
- Height 22px, inline-flex, vertical alignment center. Padding 0 8px.
- Corner radius: `9999px`.
- Left-aligned 6px circular dot indicator within the pill using the corresponding status foreground color.

### 5. Form Inputs & Search Fields
- Height 36px, border 1px solid `#CBD5E1`, background `#FFFFFF`, text `#0F172A`, placeholder `#94A3B8`.
- Focus state: Border `#2563EB`, outline none, box-shadow `0 0 0 2px rgba(37, 99, 235, 0.15)`.

### 6. Pagination Bar
- Rendered flush at the bottom of the table without floating container margins.
- Height 44px, border-top 1px solid `#E2E8F0`, background `#FFFFFF`.
- Displays total row count ("Menampilkan 1-25 dari 1.420 data") in `body-sm` (`#64748B`) on the left, with compact page selector buttons on the right.